﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

//added Skytells import
using Skytells;
//added Text to Speech imports
using System.Speech.Synthesis;
using System.Speech.Recognition;
using System.Threading;



namespace Translator
{
    public partial class ChatMain : Form
    {
        Socket sckt;
        EndPoint epLocal, epRemote;
        public String you;
        public String otherUser;

        public ChatMain()
        {
            InitializeComponent();
            sckt = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            sckt.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            txtIP.Text = GetLocalIP();
            txtIP2.Text = GetLocalIP();
            ListItems = new List<string>();
        }

        public List<string> ListItems { get; set; }

        private string GetLocalIP()
        {
            IPHostEntry host;
            host = Dns.GetHostEntry(Dns.GetHostName());

            foreach (IPAddress ip in host.AddressList)
            {
                if(ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            return "192.168.0.65";
        }


        private void MessageBack(IAsyncResult aResult)
        {
            
            try
            {
                otherUser = "Other User: ";
                int size = sckt.EndReceiveFrom(aResult, ref epRemote);
                if (size > 0)
                {
                    byte[] recievedData = new byte[1464];

                    recievedData = (byte[])aResult.AsyncState;
                    ASCIIEncoding eEncoding = new ASCIIEncoding();
                    string receievedMessage = eEncoding.GetString(recievedData);
                    listMessage.Items.Add(otherUser + receievedMessage);
                }
                byte[] buffer = new byte[1500];
                sckt.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref epRemote, new AsyncCallback(MessageBack), buffer);
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.ToString());
            }
                
        }

        private void listMessage_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            
            try
            {
                btnConnect.BackColor = Color.Lime;
                epLocal = new IPEndPoint(IPAddress.Parse(txtIP.Text), Convert.ToInt32(txtPort.Text));
                sckt.Bind(epLocal);

                epRemote = new IPEndPoint(IPAddress.Parse(txtIP2.Text), Convert.ToInt32(txtPort2.Text));
                sckt.Connect(epRemote);

                byte[] buffer = new byte[1500];
                sckt.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref epRemote, new AsyncCallback(MessageBack), buffer);
                btnConnect.Text = "Connected";
                btnConnect.Enabled = false;
                btnSend.Enabled = true;
                txtMessage.Focus();
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.ToString());
            }
        }
        
        private void btnSend_Click(object sender, EventArgs e)
        {
            
            try
            {
                you = "scum: ";
                if (txtMessage.Text == "")
                    {
                    listMessage.Items.Add("");
                    MessageBox.Show("Please enter a message to translate", "OOPS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if(Skytells.Translator.TranslateText(txtMessage.Text, cmbInput.Text, cmbOutput.Text) == true)
                {
                    System.Text.ASCIIEncoding enc = new System.Text.ASCIIEncoding();
                    byte[] msg = new byte[1500];
                    msg = enc.GetBytes(Skytells.Translator.TranslatedWord);
                    sckt.Send(msg);
                    ListItems.Add(txtMessage.Text);
                    listMessage.Items.Add (you + txtMessage.Text);
                    txtMessage.Clear();

                    
                }                
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.ToString());



            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void grb2_Enter(object sender, EventArgs e)
        {

        }

        private void txtMessage_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        SpeechSynthesizer sSynth = new SpeechSynthesizer();
        PromptBuilder pBuilder = new PromptBuilder();
        SpeechRecognitionEngine sRecognise = new SpeechRecognitionEngine();

        private void btnSpeak_Click(object sender, EventArgs e)
        {
            pBuilder.ClearContent();
            pBuilder.AppendText(ListItems[listMessage.SelectedIndex]);
            sSynth.Speak(pBuilder);
        }

      
        

        

        private void ChatMain_Load(object sender, EventArgs e)
        {
            try
            {

                txtPort.Text = Properties.Settings.Default.Port1;
                txtPort2.Text = Properties.Settings.Default.Port2;
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp);
            }



        }
    }
}
