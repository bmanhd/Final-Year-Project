﻿namespace Translator
{


    partial class AppData
    {
        partial class UsersDataTable
        {
        }
    }
}
